# Sisa edit manual (3 file, tinggal tempel)

## 1. src/main/AndroidManifest.xml  (di tag <application>)
    android:icon="@drawable/ic_launcher"
    android:dataExtractionRules="@xml/data_extraction_rules"

## 2. overlay/DragFrameLayout.kt
Tambah import:  import android.annotation.SuppressLint
Di atas class:
    @SuppressLint("ViewConstructor")
    class DragFrameLayout( ...
Di dalam class (dekat onTouchEvent):
    override fun performClick(): Boolean = super.performClick()

## 3. overlay/OverlayService.kt
Tambah import:  import android.annotation.SuppressLint
Di atas fungsi yang memanggil ServiceCompat.startForeground (baris ~72):
    @SuppressLint("InlinedApi")
