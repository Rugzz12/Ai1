package com.gameinsight.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private var pendingGame = ""

    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .setAction(CaptureService.ACTION_START)
                .putExtra(CaptureService.EXTRA_CODE, r.resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data)
                .putExtra(CaptureService.EXTRA_GAME, pendingGame)
            ContextCompat.startForegroundService(this, i)
        }
    }

    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        L.load(this)
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App(onStart = { startAnalysis(it) }, onStop = { stopAnalysis() }) }
            }
        }
    }

    private fun startAnalysis(game: String) {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        pendingGame = game
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun stopAnalysis() {
        startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
    }
}

private fun decode(ctx: Context, uri: Uri): Bitmap? = runCatching {
    val o = BitmapFactory.Options().apply { inSampleSize = 2 }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
}.getOrNull()

@Composable
fun App(onStart: (String) -> Unit, onStop: () -> Unit) {
    val ctx = LocalContext.current
    var game by remember { mutableStateOf("") }
    var shot by remember { mutableStateOf<Bitmap?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) shot = decode(ctx, uri)
    }

    val bmp = shot
    if (bmp != null) {
        val regions = remember(game) {
            mutableStateListOf<Region>().apply { addAll(Store.loadProfile(ctx, game)?.regions ?: emptyList()) }
        }
        Editor(bmp, regions) {
            Store.saveProfile(ctx, Profile(game.trim(), regions.toList()))
            shot = null
            tick++
        }
        return
    }

    val name = game.trim()
    val games = remember(tick) { Store.games(ctx) }
    val model = remember(tick, name) { Learner.model(ctx, name) }
    val hasPending = remember(tick, name) { name.isNotEmpty() && Store.loadPending(ctx, name) != null }
    val hasProfile = remember(tick, name) { name.isNotEmpty() && Store.loadProfile(ctx, name) != null }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Game Insight AI", style = MaterialTheme.typography.headlineSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { L.set(ctx, true) }, enabled = !L.isId) { Text("Indonesia") }
            Button(onClick = { L.set(ctx, false) }, enabled = L.isId) { Text("English") }
        }
        OutlinedTextField(
            value = game, onValueChange = { game = it }, singleLine = true,
            label = { Text(L.t("Nama game", "Game name")) }, modifier = Modifier.fillMaxWidth()
        )
        if (games.isNotEmpty()) {
            Text(L.t("Game tersimpan:", "Saved games:"))
            games.forEach { g -> TextButton(onClick = { game = g }) { Text(g) } }
        }
        Button(onClick = { picker.launch("image/*") }, enabled = name.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
            Text(L.t("1. Pilih screenshot & tandai area", "1. Pick screenshot & mark areas"))
        }
        Button(onClick = { onStart(name) }, enabled = hasProfile, modifier = Modifier.fillMaxWidth()) {
            Text(L.t("2. Mulai analisis", "2. Start analysis"))
        }
        OutlinedButton(onClick = {
            onStop()
            tick++
        }, modifier = Modifier.fillMaxWidth()) { Text(L.t("Berhenti", "Stop")) }

        if (hasPending) {
            Text(L.t("Sesi terakhir selesai. Hasilnya?", "Last session finished. Result?"))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { Learner.commit(ctx, name, true); tick++ }) { Text(L.t("Menang", "Win")) }
                Button(onClick = { Learner.commit(ctx, name, false); tick++ }) { Text(L.t("Kalah", "Loss")) }
            }
        }
        if (name.isNotEmpty()) {
            Text(L.t("Data belajar: ${model.wins} menang / ${model.losses} kalah", "Learning data: ${model.wins} wins / ${model.losses} losses"))
        }
        Text(
            L.t(
                "Catatan: hanya membaca layar & menganalisis. Tidak ada auto-klik, bot, atau mengubah game. Semua data tetap di HP.",
                "Note: it only reads the screen and analyzes. No auto-click, bots, or game modification. All data stays on your phone."
            ),
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun Editor(bmp: Bitmap, regions: SnapshotStateList<Region>, onDone: () -> Unit) {
    var size by remember { mutableStateOf(IntSize.Zero) }
    var start by remember { mutableStateOf<Offset?>(null) }
    var cur by remember { mutableStateOf<Offset?>(null) }
    var pend by remember { mutableStateOf<FloatArray?>(null) }
    var rname by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(8.dp)) {
        Text(L.t("Geser jari untuk menandai area (mis. gold, HP, timer).", "Drag to mark an area (e.g. gold, HP, timer)."))
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .aspectRatio(bmp.width.toFloat() / bmp.height.toFloat())
                    .onSizeChanged { size = it }
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { start = it; cur = it },
                            onDrag = { change, _ -> cur = change.position },
                            onDragEnd = {
                                val s = start
                                val c = cur
                                if (s != null && c != null && size.width > 0 && size.height > 0) {
                                    val w = size.width.toFloat()
                                    val h = size.height.toFloat()
                                    val l = (minOf(s.x, c.x) / w).coerceIn(0f, 1f)
                                    val r = (maxOf(s.x, c.x) / w).coerceIn(0f, 1f)
                                    val t = (minOf(s.y, c.y) / h).coerceIn(0f, 1f)
                                    val b = (maxOf(s.y, c.y) / h).coerceIn(0f, 1f)
                                    if (r - l > 0.01f && b - t > 0.01f) pend = floatArrayOf(l, t, r, b)
                                }
                                start = null; cur = null
                            },
                            onDragCancel = { start = null; cur = null }
                        )
                    }
            ) {
                Image(bitmap = bmp.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize())
                Canvas(Modifier.fillMaxSize()) {
                    regions.forEach {
                        drawRect(
                            Color.Green, Offset(it.l * size.width, it.t * size.height),
                            Size((it.r - it.l) * size.width, (it.b - it.t) * size.height), style = Stroke(3f)
                        )
                    }
                    val s = start
                    val c = cur
                    if (s != null && c != null) {
                        drawRect(
                            Color.Yellow, Offset(minOf(s.x, c.x), minOf(s.y, c.y)),
                            Size(kotlin.math.abs(c.x - s.x), kotlin.math.abs(c.y - s.y)), style = Stroke(3f)
                        )
                    }
                }
            }
        }
        Text(L.t("Area: ", "Areas: ") + regions.joinToString { "${it.name}(${it.kind})" })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { if (regions.isNotEmpty()) regions.removeAt(regions.lastIndex) }) {
                Text(L.t("Hapus terakhir", "Undo last"))
            }
            Button(onClick = onDone) { Text(L.t("Simpan", "Save")) }
        }
    }

    val p = pend
    if (p != null) {
        fun add(kind: String) {
            val n = rname.trim()
            if (n.isNotEmpty()) {
                regions.removeAll { it.name == n }
                regions.add(Region(n, kind, p[0], p[1], p[2], p[3]))
                rname = ""
                pend = null
            }
        }
        AlertDialog(
            onDismissRequest = { pend = null },
            title = { Text(L.t("Nama area", "Area name")) },
            text = {
                OutlinedTextField(
                    value = rname, onValueChange = { rname = it }, singleLine = true,
                    label = { Text(L.t("mis. gold", "e.g. gold")) }
                )
            },
            confirmButton = {
                Row {
                    TextButton(onClick = { add("NUM") }) { Text(L.t("Angka", "Number")) }
                    TextButton(onClick = { add("TEXT") }) { Text(L.t("Teks", "Text")) }
                }
            },
            dismissButton = { TextButton(onClick = { pend = null }) { Text(L.t("Batal", "Cancel")) } }
        )
    }
}
