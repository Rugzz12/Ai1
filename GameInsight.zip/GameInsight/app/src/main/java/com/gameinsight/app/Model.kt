package com.gameinsight.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs

/** Bahasa: hanya Indonesia (id) dan Inggris (en). */
object L {
    var isId by mutableStateOf(true)
    fun load(c: Context) { isId = c.getSharedPreferences("gi", 0).getBoolean("id", true) }
    fun set(c: Context, id: Boolean) {
        isId = id
        c.getSharedPreferences("gi", 0).edit().putBoolean("id", id).apply()
    }
    fun t(id: String, en: String) = if (isId) id else en
}

/** Area layar (koordinat 0..1). kind = "NUM" (angka) atau "TEXT". */
data class Region(val name: String, val kind: String, val l: Float, val t: Float, val r: Float, val b: Float)
data class Profile(val game: String, val regions: List<Region>)

object Store {
    private fun key(g: String) =
        g.trim().lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').ifEmpty { "game" }

    private fun file(c: Context, prefix: String, g: String) = File(c.filesDir, "${prefix}_${key(g)}.json")

    fun games(c: Context): List<String> =
        c.filesDir.listFiles { f -> f.name.startsWith("profile_") }
            ?.mapNotNull { runCatching { JSONObject(it.readText()).getString("game") }.getOrNull() }
            ?.sorted() ?: emptyList()

    fun saveProfile(c: Context, p: Profile) {
        val arr = JSONArray()
        p.regions.forEach {
            arr.put(
                JSONObject().put("name", it.name).put("kind", it.kind)
                    .put("l", it.l.toDouble()).put("t", it.t.toDouble())
                    .put("r", it.r.toDouble()).put("b", it.b.toDouble())
            )
        }
        file(c, "profile", p.game).writeText(JSONObject().put("game", p.game).put("regions", arr).toString())
    }

    fun loadProfile(c: Context, g: String): Profile? = runCatching {
        val o = JSONObject(file(c, "profile", g).readText())
        val a = o.getJSONArray("regions")
        Profile(o.getString("game"), (0 until a.length()).map {
            val r = a.getJSONObject(it)
            Region(
                r.getString("name"), r.getString("kind"),
                r.getDouble("l").toFloat(), r.getDouble("t").toFloat(),
                r.getDouble("r").toFloat(), r.getDouble("b").toFloat()
            )
        })
    }.getOrNull()

    private fun toJson(m: Map<String, Double>) = JSONObject().also { o -> m.forEach { (k, v) -> o.put(k, v) } }
    private fun fromJson(o: JSONObject): Map<String, Double> = o.keys().asSequence().associateWith { o.getDouble(it) }

    fun savePending(c: Context, g: String, f: Map<String, Double>) =
        file(c, "pending", g).writeText(toJson(f).toString())

    fun loadPending(c: Context, g: String): Map<String, Double>? =
        runCatching { fromJson(JSONObject(file(c, "pending", g).readText())) }.getOrNull()

    fun clearPending(c: Context, g: String) { file(c, "pending", g).delete() }

    fun sessions(c: Context, g: String): List<Pair<Map<String, Double>, Boolean>> = runCatching {
        val a = JSONArray(file(c, "sessions", g).readText())
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            fromJson(o.getJSONObject("f")) to o.getBoolean("win")
        }
    }.getOrDefault(emptyList())

    fun addSession(c: Context, g: String, f: Map<String, Double>, win: Boolean) {
        val a = runCatching { JSONArray(file(c, "sessions", g).readText()) }.getOrDefault(JSONArray())
        a.put(JSONObject().put("win", win).put("f", toJson(f)))
        file(c, "sessions", g).writeText(a.toString())
    }
}

/**
 * Pembelajaran ringan, 100% lokal: belajar dari hasil match (menang/kalah) milikmu sendiri.
 * Tiap sesi diringkas jadi fitur (mean/last/delta tiap angka), lalu dibandingkan dengan
 * rata-rata sesi menang vs kalah. Tidak mengubah game dan tidak mengirim data ke mana pun.
 */
object Learner {
    class Model(val winMean: Map<String, Double>, val lossMean: Map<String, Double>, val wins: Int, val losses: Int)

    fun feats(values: Map<String, List<Double>>): Map<String, Double> {
        val m = LinkedHashMap<String, Double>()
        for ((k, v) in values) {
            if (v.isEmpty()) continue
            m["$k.mean"] = v.average()
            m["$k.last"] = v.last()
            m["$k.delta"] = v.last() - v.first()
        }
        return m
    }

    fun commit(c: Context, g: String, win: Boolean): Boolean {
        val p = Store.loadPending(c, g) ?: return false
        Store.addSession(c, g, p, win)
        Store.clearPending(c, g)
        return true
    }

    fun model(c: Context, g: String): Model {
        val s = Store.sessions(c, g)
        fun avg(w: Boolean): Map<String, Double> {
            val grp = s.filter { it.second == w }.map { it.first }
            val keys = grp.flatMap { it.keys }.toSet()
            return keys.associateWith { k -> grp.mapNotNull { it[k] }.average() }
        }
        return Model(avg(true), avg(false), s.count { it.second }, s.count { !it.second })
    }

    fun hint(m: Model, cur: Map<String, Double>): String {
        if (m.wins < 2 || m.losses < 2) {
            return L.t(
                "Belajar: butuh min. 2 menang & 2 kalah (sekarang ${m.wins}/${m.losses})",
                "Learning: needs 2 wins & 2 losses (now ${m.wins}/${m.losses})"
            )
        }
        var w = 0
        var l = 0
        for ((k, c) in cur) {
            if (!k.endsWith(".mean")) continue
            val a = m.winMean[k] ?: continue
            val b = m.lossMean[k] ?: continue
            if (a == b) continue
            if (abs(c - a) < abs(c - b)) w++ else l++
        }
        if (w + l == 0) return "-"
        return L.t("Pola: $w sinyal mirip menang, $l mirip kalah", "Pattern: $w signals look like wins, $l like losses")
    }
}
