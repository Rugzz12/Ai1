package com.gameinsight.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

/**
 * Membaca layar (MediaProjection) ~1 frame/detik, OCR hanya pada area yang kamu tandai,
 * lalu menampilkan insight di bubble. HANYA MEMBACA: tidak ada klik/otomatisasi apa pun.
 */
class CaptureService : Service() {
    companion object {
        const val ACTION_START = "gi.start"
        const val ACTION_STOP = "gi.stop"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_GAME = "game"
        private const val CH = "gi_capture"
        private const val SCALE = 0.6f
        private const val INTERVAL_MS = 1000L
        private const val MAX_SAMPLES = 7200
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private var wm: WindowManager? = null
    private var bubble: TextView? = null
    private val busy = AtomicBoolean(false)
    private val ui = Handler(Looper.getMainLooper())
    private var last = 0L
    private var running = false
    private var stopping = false
    private var game = ""
    private var profile: Profile? = null
    private var model: Learner.Model? = null
    private val values = LinkedHashMap<String, MutableList<Double>>()
    private var shown = "🧠"
    private var collapsed = false
    private var frames = 0
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopAll()
            ACTION_START -> if (!running) {
                try {
                    start(intent)
                } catch (e: Exception) {
                    stopAll()
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        L.load(this)
        stopping = false
        values.clear()
        frames = 0
        game = intent.getStringExtra(EXTRA_GAME) ?: ""
        profile = Store.loadProfile(this, game)
        model = Learner.model(this, game)

        val notif = notification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notif)
        }

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        @Suppress("DEPRECATION")
        val data: Intent = (if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else intent.getParcelableExtra(EXTRA_DATA)) ?: throw IllegalStateException("no data")

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { ui.post { stopAll() } }
        }, ui)

        val dm = resources.displayMetrics
        val w = (dm.widthPixels * SCALE).toInt()
        val h = (dm.heightPixels * SCALE).toInt()
        val t = HandlerThread("gi-cap").also { it.start() }
        thread = t
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        vd = p.createVirtualDisplay(
            "gi", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAGS_AUTO_MIRROR, r.surface, null, null
        )
        r.setOnImageAvailableListener({ onFrame(it) }, Handler(t.looper))
        showBubble()
        running = true
        render(L.t("Menganalisis… ($game)", "Analyzing… ($game)"))
    }

    private fun onFrame(r: ImageReader) {
        val img = try { r.acquireLatestImage() } catch (e: Exception) { null } ?: return
        val now = SystemClock.elapsedRealtime()
        val prof = profile
        if (now - last < INTERVAL_MS || busy.get() || prof == null || prof.regions.isEmpty()) {
            img.close()
            return
        }
        busy.set(true)
        last = now
        val vw = r.width
        val vh = r.height
        val bmp = try {
            val p = img.planes[0]
            val pad = p.rowStride - p.pixelStride * vw
            Bitmap.createBitmap(vw + pad / p.pixelStride, vh, Bitmap.Config.ARGB_8888)
                .also { it.copyPixelsFromBuffer(p.buffer) }
        } catch (e: Exception) { null } finally { img.close() }
        if (bmp == null) { busy.set(false); return }

        val results = ConcurrentHashMap<String, String>()
        val remaining = AtomicInteger(prof.regions.size)
        for (reg in prof.regions) {
            val x = (reg.l * vw).toInt().coerceIn(0, vw - 1)
            val y = (reg.t * vh).toInt().coerceIn(0, vh - 1)
            val cw = ((reg.r - reg.l) * vw).toInt().coerceIn(1, vw - x)
            val ch = ((reg.b - reg.t) * vh).toInt().coerceIn(1, vh - y)
            val crop = try { Bitmap.createBitmap(bmp, x, y, cw, ch) } catch (e: Exception) { null }
            if (crop == null) {
                if (remaining.decrementAndGet() == 0) { bmp.recycle(); finish(results) }
                continue
            }
            recognizer.process(InputImage.fromBitmap(crop, 0))
                .addOnSuccessListener { results[reg.name] = it.text }
                .addOnCompleteListener {
                    crop.recycle()
                    if (remaining.decrementAndGet() == 0) { bmp.recycle(); finish(results) }
                }
        }
    }

    private fun parseNum(s: String): Double? {
        val m = Regex("\\d[\\d.,]*").find(s) ?: return null
        return m.value.replace(".", "").replace(",", "").toDoubleOrNull()
    }

    private fun finish(results: Map<String, String>) {
        val prof = profile
        if (prof == null || !running) { busy.set(false); return }
        val sb = StringBuilder()
        for (reg in prof.regions) {
            val txt = results[reg.name].orEmpty().trim().replace("\n", " ")
            if (reg.kind == "NUM") {
                val n = parseNum(txt)
                val list = values.getOrPut(reg.name) { mutableListOf() }
                if (n != null && list.size < MAX_SAMPLES) list.add(n)
                val cur = list.lastOrNull()
                val prev = if (list.size > 5) list[list.size - 6] else null
                val arrow = if (cur == null || prev == null) "" else if (cur > prev) " ▲" else if (cur < prev) " ▼" else " ="
                sb.append("${reg.name}: ${cur?.toLong() ?: "?"}$arrow\n")
            } else {
                sb.append("${reg.name}: ${txt.ifEmpty { "?" }}\n")
            }
        }
        frames++
        val m = model
        if (m != null) sb.append(Learner.hint(m, Learner.feats(values)))
        render(sb.toString().trim())
        busy.set(false)
    }

    private fun render(text: String? = null) {
        if (text != null) shown = text
        bubble?.text = if (collapsed) "🧠" else shown
    }

    private fun showBubble() {
        val manager = getSystemService(WindowManager::class.java)
        wm = manager
        val tv = TextView(this).apply {
            text = "🧠"
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(24, 16, 24, 16)
            setBackgroundColor(0xCC202020.toInt())
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 200 }
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - dx).toInt()
                    val my = (e.rawY - dy).toInt()
                    if (abs(mx) > 10 || abs(my) > 10) moved = true
                    lp.x = sx + mx; lp.y = sy + my
                    manager.updateViewLayout(tv, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) { collapsed = !collapsed; render() }
            }
            true
        }
        manager.addView(tv, lp)
        bubble = tv
    }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Game Insight", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Game Insight AI")
            .setContentText(L.t("Sedang membaca layar (hanya analisis)", "Reading screen (analysis only)"))
            .addAction(Notification.Action.Builder(null, L.t("Berhenti", "Stop"), stop).build())
            .setOngoing(true)
            .build()
    }

    private fun stopAll() {
        if (stopping) return
        stopping = true
        running = false
        runCatching { vd?.release() }
        runCatching { reader?.close() }
        runCatching { projection?.stop() }
        runCatching { thread?.quitSafely() }
        bubble?.let { b -> runCatching { wm?.removeView(b) } }
        bubble = null
        if (values.values.any { it.isNotEmpty() } && game.isNotEmpty()) {
            Store.savePending(this, game, Learner.feats(values))
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }
}
